<!-- Navigation -->
<nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
    <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="index.php">Welcome!</a>
    </div>
</nav>