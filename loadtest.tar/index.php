<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Azure VM Auto Scaling</title>

    <!-- Custom fonts for this theme -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Theme CSS -->
    <link href="css/freelancer.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Masthead -->
    <header class="masthead bg-primary text-white text-center">
        <div class="c d-flex align-items-center flex-column">

            <!-- Masthead Avatar Image -->
            <img class="masthead-avatar mb-5" src="" alt="">

        </div>
    </header>

    <!-- Footer -->
    <footer class="footer text-center">
        <div class="container">
            <h3>Instance data</h3>
            <p></p>
             <!-- Metadata -->
             <?php

# Print hostname
echo "<h6 class='masthead-front'><font color='#ff9900'>Hostname: </font>" . gethostname() . "</h6>";
echo "<p></p>";
          ?>
        </div>
    </footer>

<div class="divider-custom">
    <div class="divider-custom-line"></div>
    <div class="divider-custom-icon">
    <i class="fas fa-star"></i>
    </div>
    <div class="divider-custom-line"></div>
</div>
<h5 class="text-center"><a href="cpu-load.php"><u>Start CPU Load Generation</u></a></h5>
<h2 class="text-center"><?php include('get-cpu-load.php'); ?></h2>


</body>

</html>
